package com.toolvip;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.DataOutputStream;

public class MainActivity extends AppCompatActivity {
    private String corefile = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String arch = System.getProperty("os.arch").toLowerCase();
        TextView status = findViewById(R.id.lblStatus);
        
        if (arch.contains("arm64") || arch.contains("aarch64")) {
            corefile = "core_rust_64";
            status.setText("TƯƠNG THÍCH: 64-BIT");
        } else {
            corefile = "core_rust_32";
            status.setText("TƯƠNG THÍCH: 32-BIT");
        }

        addEvent(R.id.swTouchMax, "touch_max");
        addEvent(R.id.swInstant, "instant");
        addEvent(R.id.swGyro, "gyro_fix");
        addEvent(R.id.swPingThap, "ping_low");
        addEvent(R.id.swMaxGpu, "gpu_boost_rust");
    }

    private void addEvent(int id, final String cmdKey) {
        Switch sw = findViewById(id);
        if (sw != null) {
            sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        executeCore(cmdKey);
                    }
                }
            });
        }
    }

    private void executeCore(String action) {
        Toast.makeText(this, "Kích hoạt: " + action, Toast.LENGTH_SHORT).show();
        String path = getApplicationInfo().dataDir + "/assets/" + corefile;
        try {
            Process p = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(p.getOutputStream());
            os.writeBytes("su -c '" + path + " --action=" + action + "'\n");
            os.writeBytes("exit\n");
            os.flush();
            os.close();
        } catch (Exception e) {}
    }
}
